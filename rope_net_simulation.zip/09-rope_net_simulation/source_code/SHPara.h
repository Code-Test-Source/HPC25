 															//

#ifndef _SHPARA_H_
#define _SHPARA_H_

#include "LoadPolyhedron.h"
#include "MatrixOperations.h"

void LoadSHPara(const char* filename, double* SurfacePara);

#endif
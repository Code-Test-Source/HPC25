 																//

#ifndef _CALGF_H_
#define _CALGF_H_

#include "LoadPolyhedron.h"

void GravAttraction(const POLYHEDRON &p, double* r, double* F);

#endif
#!/bin/bash

cp -r /lustre/share/xflops/wrf/* .

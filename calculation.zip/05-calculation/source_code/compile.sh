#!/bin/bash

# Write your compile command:
# <example>
g++ main.cpp -o calculation
# </example>
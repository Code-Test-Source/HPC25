# Calcultion Writeup

## How I think:

## How I optimize:

## (Add whatever you want)...
#!/bin/bash

mkdir data
cp -r /lustre/share/xflops/calculation/main_data/* data/
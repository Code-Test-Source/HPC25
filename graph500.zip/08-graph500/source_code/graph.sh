#! bin/bash

# Add the module you need

make clean

make

# Run the executable with the specific arguments
./graph500_reference_bfs_sssp 18

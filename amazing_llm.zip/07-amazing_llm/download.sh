basedir=$(dirname "$0")
cp /lustre/share/xflops/amazing_llm/vllm.tar.gz $basedir/source_code
echo download vllm.tar.gz to $basedir/source_code
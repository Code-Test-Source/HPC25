#!/bin/bash

# Write your compile command:
# <example>
g++ -O3 -march=native -ffast-math -funroll-loops main.cpp -o calculation
# </example>
# Ocean Sim
使用了OpenMP并行化来利用多核性能，并对一些计算密集型循环进行了优化